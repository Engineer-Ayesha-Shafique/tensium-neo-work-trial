"""Lay out the task from real data (deterministic). Run once: python3 task/setup.py

Source: the Wisconsin Diagnostic Breast Cancer dataset (569 real fine-needle-aspirate
records, 30 cell-nucleus features) as bundled with scikit-learn -- no download needed.

Writes:
  workspace/data/train.csv          labelled training records (agent-visible)
  workspace/data/smoke_batch.csv    60 labelled records for the visible smoke check
  workspace/data/live_sample.csv    one real live batch, features only
  service/hidden_stream.npz         the held-out live stream + labels (env side)
  service/config.json               serving / validation config (env side)
  service/state/                    action log + deployed release (written by the ops service)
then trains the shipped model (workspace/pipeline/train.py).
"""
import csv
import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

TASK = Path(__file__).resolve().parent
WS = TASK / "workspace"
SERVICE = TASK / "service"
BATCH = 20


def write_csv(path, names, X, y=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(list(names) + (["label"] if y is not None else []))
        for i, row in enumerate(X):
            w.writerow([f"{v:.6g}" for v in row] + ([int(y[i])] if y is not None else []))


def main():
    d = load_breast_cancer()
    names = [n.replace(" ", "_") for n in d.feature_names]
    Xtr, Xlive, ytr, ylive = train_test_split(
        d.data, d.target, test_size=0.4, random_state=7, stratify=d.target)

    # Live traffic arrives one scanning session per batch; sessions are triage-ordered
    # (largest lesions are read first), so each batch is homogeneous in lesion size.
    order = np.argsort(Xlive[:, names.index("mean_area")], kind="stable")
    Xlive, ylive = Xlive[order], ylive[order]

    write_csv(WS / "data" / "train.csv", names, Xtr, ytr)
    rs = np.random.RandomState(0)
    idx = rs.choice(len(Xtr), 60, replace=False)
    write_csv(WS / "data" / "smoke_batch.csv", names, Xtr[idx], ytr[idx])
    write_csv(WS / "data" / "live_sample.csv", names, Xlive[3 * BATCH:4 * BATCH])

    if SERVICE.exists():
        shutil.rmtree(SERVICE)
    SERVICE.mkdir()
    np.savez(SERVICE / "hidden_stream.npz", X=Xlive, y=ylive)
    (SERVICE / "config.json").write_text(json.dumps(
        {"batch_size": BATCH, "validate_budget": 4, "pass_bar_accuracy": 0.94,
         "invariance_min_agreement": 0.995, "inject_fault_until_recovered": True},
        indent=2) + "\n")

    subprocess.run([sys.executable, str(WS / "pipeline" / "train.py")], check=True)
    for p in (WS / ".envstate", WS / "pipeline" / "__pycache__"):   # nothing stale in the workspace
        if p.exists():
            shutil.rmtree(p)
    print(f"setup ok: train={len(Xtr)} live={len(Xlive)} batches={-(-len(Xlive) // BATCH)}")


if __name__ == "__main__":
    main()
