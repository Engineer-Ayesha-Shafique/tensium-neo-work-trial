"""Operations service for the lesion triage serving pipeline (env side).

Usage:  python3 env_cli.py <op> [--family NAME]     (workspace/env_cli.py forwards here)

Observation (not logged):   inspect | sample_records
Operational (logged, gated): reproduce -> deploy -> validate -> [diagnostics.read ->
                             recovery.apply --family NAME] -> promote -> submit

This file and everything under service/ live outside the agent's workspace. The action
log, the deploy manifest and the deployed release are kept in service/state/, so the agent
can neither read nor write them. State is rebuilt by replaying the log, so it persists
across separate shell calls.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

ENV = Path(__file__).resolve().parent
TASK = ENV.parent
SERVICE = TASK / "service"          # no env-var override: the caller's environment is the agent's
CFG = json.loads((SERVICE / "config.json").read_text())
WS = Path(CFG.get("workspace_dir", TASK / "workspace"))
STATE = SERVICE / "state"
LOG = STATE / "actions.jsonl"
DEPLOYED = STATE / "deployed"
UPLOAD = STATE / "upload"
RELEASE_DIRS = ("pipeline", "artifacts", "data")
RECOVERY_FAMILIES = ("rebuild_artifact", "rollback_artifact", "clear_feature_cache")

WORKER = r"""
import importlib.util, sys
import numpy as np
serve_path, x_path, out_path, bs = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
spec = importlib.util.spec_from_file_location("serve", serve_path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
X = np.load(x_path)
out = [np.asarray(mod.predict(X[i:i + bs])).astype(int).ravel() for i in range(0, len(X), bs)]
np.save(out_path, np.concatenate(out))
"""


class Rejected(Exception):
    pass


# ---------------------------------------------------------------- log + state

def read_log():
    if not LOG.exists():
        return []
    return [json.loads(line) for line in LOG.read_text().splitlines() if line.strip()]


def append(op, result):
    STATE.mkdir(parents=True, exist_ok=True)
    entries = read_log()
    with open(LOG, "a") as f:
        f.write(json.dumps({"seq": len(entries) + 1, "op": op, "result": result}) + "\n")


def state():
    s = {"reproduced": False, "deploys": 0, "validates": 0, "last_validate": None,
         "diagnosed": False, "recovered": False, "promoted": False, "submitted": False}
    for e in read_log():
        op, r = e["op"], e["result"]
        if op == "reproduce":
            s["reproduced"] = True
        elif op == "deploy":
            s.update(deploys=s["deploys"] + 1, last_validate=None, promoted=False, diagnosed=False)
        elif op == "validate":
            s.update(validates=s["validates"] + 1, last_validate=r["status"], diagnosed=False)
        elif op == "diagnostics.read":
            s["diagnosed"] = True
        elif op == "recovery.apply":
            s.update(last_validate=None, diagnosed=False, recovered=True)
        elif op == "promote":
            s["promoted"] = True
        elif op == "submit":
            s["submitted"] = True
    return s


# ---------------------------------------------------------------- helpers

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def release_sha256(root):
    """One hash over every file of a release, so the graded release can be tied to the
    validated one."""
    h = hashlib.sha256()
    for sub in RELEASE_DIRS:
        for p in sorted((Path(root) / sub).rglob("*")):
            if p.is_file():
                h.update(str(p.relative_to(root)).encode() + b"\0" + p.read_bytes() + b"\0")
    return h.hexdigest()


def refuse_symlinks(root):
    """The service can read what the agent cannot. Never follow a link the agent planted."""
    for sub in RELEASE_DIRS:
        top = Path(root) / sub
        for p in [top, *top.rglob("*")]:
            if p.is_symlink():
                raise Rejected(f"{p.relative_to(root)} is a symlink; releases must be plain files")


def run_candidate(root, X, batch_size, timeout=60):
    """Run <root>/pipeline/serve.py over X and return its predictions.

    The candidate is agent code. It runs on a throwaway copy of the release, in its own
    process, sees features only, gets a scrubbed environment, and loses the service's
    privileges when the service runs as root.
    """
    with tempfile.TemporaryDirectory() as td:
        stage = Path(td) / "release"
        for sub in RELEASE_DIRS:
            if (Path(root) / sub).is_dir():
                shutil.copytree(Path(root) / sub, stage / sub, symlinks=True)
        xp, op = stage / ".x.npy", stage / ".out.npy"
        np.save(xp, X)
        kw = {"env": {"PATH": os.environ.get("PATH", ""), "PYTHONDONTWRITEBYTECODE": "1"}}
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            uid = int(CFG.get("sandbox_uid", 65534))
            os.chmod(td, 0o755)
            for p in [stage, *stage.rglob("*")]:
                os.chown(p, uid, uid, follow_symlinks=False)
            kw.update(user=uid, group=uid, extra_groups=[])
        p = subprocess.run(
            [sys.executable, "-c", WORKER, str(stage / "pipeline" / "serve.py"), str(xp), str(op),
             str(batch_size)], cwd=stage, capture_output=True, text=True, timeout=timeout, **kw)
        if p.returncode != 0 or not op.exists():
            tail = (p.stderr.strip().splitlines() or ["no output"])[-1]
            raise RuntimeError(f"candidate raised: {tail}")
        return np.load(op, allow_pickle=False)


def score_release(root, X, y):
    """Accuracy on the stream as it arrives, plus agreement with a second pass in which the
    same rows arrive in shuffled batches. A record's answer must not depend on its
    batch-mates. Returns (accuracy, agreement)."""
    bs = CFG["batch_size"]
    pred = run_candidate(root, X, bs)
    if pred.shape != (len(X),) or not np.isin(pred, (0, 1)).all():
        raise RuntimeError("candidate must return one 0/1 label per row")
    perm = np.random.RandomState(CFG.get("invariance_seed", 20240229)).permutation(len(X))
    again = np.empty(len(X), dtype=int)
    again[perm] = run_candidate(root, X[perm], bs)
    return float((pred == y).mean()), float((pred == again).mean())


def load_csv(path):
    import csv
    with open(path) as f:
        r = csv.reader(f)
        header = next(r)
        rows = [list(map(float, row)) for row in r]
    return header, np.array(rows)


# ---------------------------------------------------------------- ops

def op_inspect(_args):
    header, _ = load_csv(WS / "data" / "train.csv")
    return {
        "pipeline": "pipeline/train.py -> artifacts/{model.pkl,scaler.pkl}; pipeline/serve.py:predict(X)",
        "features": header[:-1],
        "label": "0 = malignant, 1 = benign",
        "serving": f"live traffic arrives one scanning session per batch "
                   f"(batch_size={CFG['batch_size']}); sessions are read in triage order",
        "validate_budget": CFG["validate_budget"],
    }


def op_sample_records(_args):
    header, X = load_csv(WS / "data" / "live_sample.csv")
    cols = ["mean_radius", "mean_texture", "mean_area", "worst_concave_points"]
    idx = [header.index(c) for c in cols]
    return {"live_batch_sample": [dict(zip(cols, map(float, row[idx]))) for row in X[:5]]}


def op_reproduce(_args):
    _, a = load_csv(WS / "data" / "smoke_batch.csv")
    try:
        refuse_symlinks(WS)
        pred = run_candidate(WS, a[:, :-1], batch_size=len(a))
        acc = float((pred == a[:, -1].astype(int)).mean())
    except Exception as exc:  # noqa: BLE001
        return {"smoke_accuracy": None, "error": str(exc)}
    return {"smoke_accuracy": round(acc, 3), "smoke_check": "pass" if acc >= 0.95 else "fail"}


def op_deploy(_args):
    s = state()
    if not s["reproduced"]:
        raise Rejected("deploy requires reproduce first")
    refuse_symlinks(WS)
    n = s["deploys"] + 1
    for d in (DEPLOYED, UPLOAD):
        if d.exists():
            shutil.rmtree(d)
    for sub in RELEASE_DIRS:
        shutil.copytree(WS / sub, DEPLOYED / sub, symlinks=True)
    shutil.copytree(WS / "artifacts", UPLOAD / "artifacts", symlinks=True)
    manifest = {"model_sha256": sha256(DEPLOYED / "artifacts" / "model.pkl")}
    (STATE / "manifest.json").write_text(json.dumps(manifest))
    if CFG["inject_fault_until_recovered"] and not s["recovered"]:
        # the artifact-store upload is interrupted part-way, and keeps being interrupted
        # until the store has been rebuilt once. Deploying again does not get around it.
        mp = DEPLOYED / "artifacts" / "model.pkl"
        data = mp.read_bytes()
        mp.write_bytes(data[: int(len(data) * 0.41)])
    return {"deploy_id": n, "status": "deployed"}


def op_validate(_args):
    s = state()
    if s["deploys"] == 0:
        raise Rejected("validate requires a deploy")
    if s["validates"] >= CFG["validate_budget"]:
        raise Rejected(f"validate budget exhausted ({CFG['validate_budget']})")

    # read straight from the service store; nothing about the stream is written anywhere
    # the agent can see
    stream = np.load(SERVICE / "hidden_stream.npz")

    manifest = json.loads((STATE / "manifest.json").read_text())
    if sha256(DEPLOYED / "artifacts" / "model.pkl") != manifest["model_sha256"]:
        return {"status": "FAILED",
                "detail": "deployment unhealthy; run diagnostics.read"}
    try:
        acc, agree = score_release(DEPLOYED, stream["X"], stream["y"])
    except Exception as exc:  # noqa: BLE001
        return {"status": "dirty", "detail": str(exc)}
    ok = acc >= CFG["pass_bar_accuracy"] and agree >= CFG["invariance_min_agreement"]
    return {"status": "clean" if ok else "dirty", "release_sha256": release_sha256(DEPLOYED)}


def op_diagnostics_read(_args):
    if state()["last_validate"] != "FAILED":
        raise Rejected("no failed validation to diagnose")
    size = (DEPLOYED / "artifacts" / "model.pkl").stat().st_size
    full = (UPLOAD / "artifacts" / "model.pkl").stat().st_size
    return {"symptom": f"deployed artifacts/model.pkl is {size} bytes; the deploy manifest "
                       f"recorded {full}. The artifact-store upload was interrupted.",
            "recovery_families": list(RECOVERY_FAMILIES)}


def op_recovery_apply(args):
    if not state()["diagnosed"]:
        raise Rejected("recovery.apply requires diagnostics.read after a failed validate")
    fam = args.get("family")
    if fam not in RECOVERY_FAMILIES:
        raise Rejected(f"unknown family {fam!r}")
    if fam != "rebuild_artifact":
        raise Rejected(f"family {fam!r} does not match the diagnosed symptom")
    shutil.rmtree(DEPLOYED / "artifacts")
    shutil.copytree(UPLOAD / "artifacts", DEPLOYED / "artifacts", symlinks=True)
    return {"family": fam, "status": "applied"}


def op_promote(_args):
    if state()["last_validate"] != "clean":
        raise Rejected("promote requires a clean validate on the current deploy")
    return {"status": "promoted"}


def op_submit(_args):
    if not state()["promoted"]:
        raise Rejected("submit requires promote")
    return {"status": "submitted"}


OPS = {"inspect": op_inspect, "sample_records": op_sample_records, "reproduce": op_reproduce,
       "deploy": op_deploy, "validate": op_validate, "diagnostics.read": op_diagnostics_read,
       "recovery.apply": op_recovery_apply, "promote": op_promote, "submit": op_submit}
UNLOGGED = {"inspect", "sample_records"}


def main(argv):
    if not argv or argv[0] not in OPS:
        print(__doc__)
        return 2
    op, args = argv[0], {}
    if "--family" in argv and argv.index("--family") + 1 < len(argv):
        args["family"] = argv[argv.index("--family") + 1]
    try:
        if op not in UNLOGGED and state()["submitted"]:
            raise Rejected("already submitted; the release is frozen")
        result = OPS[op](args)
    except Rejected as exc:
        print(json.dumps({"op": op, "rejected": str(exc)}))
        return 2
    if op not in UNLOGGED:
        append(op, result)
    shown = {k: v for k, v in result.items() if k != "release_sha256"}   # log-only field
    print(json.dumps({"op": op, **shown}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
