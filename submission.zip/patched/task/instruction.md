Hey -- need you to take over the lesion triage classifier incident.

Since intake switched to scanning sessions (each live batch is one session, and sessions are
read in triage order), live accuracy has fallen to roughly 60%. Offline eval still says 98%
and the smoke check passes, so nobody trusts the dashboards right now. Find out what is
actually wrong, fix it, and get a healthy release promoted.

The pipeline lives in `/workspace/target/`:

- `pipeline/train.py` -- trains the model and writes `artifacts/` and `data/train_stats.json`
- `pipeline/serve.py` -- `predict(X)` scores one live batch (the serving contract is in its docstring)
- `tests/test_smoke.py` -- the visible smoke check

You drive the release through the ops service, `python3 env_cli.py <op>`:

| op | what it does |
|---|---|
| `inspect`, `sample_records` | read-only: pipeline config, serving protocol, a real live batch |
| `reproduce` | runs your current `serve.py` on the smoke batch |
| `deploy` | snapshots your current code + artifacts as the candidate release |
| `validate` | runs the deployed release over live traffic; returns only `clean` / `dirty`. **Budget: 4 calls in total.** If it returns `FAILED`, the deploy itself is unhealthy |
| `diagnostics.read` | explains a `FAILED` validate |
| `recovery.apply --family NAME` | applies a recovery; the family must match the diagnosis |
| `promote` | requires a `clean` validate on the current deploy |
| `submit` | freezes the promoted release for review |

Order matters: `reproduce` -> `deploy` -> `validate` -> (diagnose + recover if it failed) ->
`promote` -> `submit`. The deliverable is the driven release ending in `submit` -- not a
write-up, and not just a code change. The promoted release is scored on held-out live traffic:
a healthy release is at least 94% accurate there.

No internet access. Work only inside `/workspace/target/`.
