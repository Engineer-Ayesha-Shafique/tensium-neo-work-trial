"""Client for the operations service of the lesion triage serving pipeline.

Usage:  python3 env_cli.py <op> [--family NAME]

Observation (not logged):   inspect | sample_records
Operational (logged, gated): reproduce -> deploy -> validate -> [diagnostics.read ->
                             recovery.apply --family NAME] -> promote -> submit

This file only forwards the call. The service, its action log and the deployed release
live on the env side, outside the workspace. Editing this file changes nothing the
verifier looks at.
"""
import subprocess
import sys
from pathlib import Path

# In the image this call crosses the privilege boundary (the service runs as its own user).
SERVICE_ENTRY = Path(__file__).resolve().parent.parent / "env" / "ops_service.py"

if __name__ == "__main__":
    sys.exit(subprocess.run([sys.executable, str(SERVICE_ENTRY), *sys.argv[1:]]).returncode)
