"""Verifier: replay the accepted-action log, then grade the promoted release by value.

    strict_pass = terminal_ok AND gate_walk_ok AND forced_recovery_ok   -> reward 1.0, else 0.0

Reads the log and the release from <service>/state/, which the ops service writes and the
agent cannot. Nothing under workspace/ is trusted. The release is agent code: it runs in a
separate process that is handed features only.

Writes the reward to $REWARD_DIR/reward.txt (default: <task>/logs/verifier/).
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

TASK = Path(__file__).resolve().parent.parent
SERVICE = Path(os.environ.get("TASK_SERVICE_DIR", TASK / "service"))
REWARD_DIR = Path(os.environ.get("REWARD_DIR", TASK / "logs" / "verifier"))
STATE = SERVICE / "state"
CFG = json.loads((SERVICE / "config.json").read_text())

BAR = CFG["pass_bar_accuracy"]      # one source of truth, shared with `validate`
BATCH = CFG["batch_size"]
RELEASE_DIRS = ("pipeline", "artifacts", "data")
TIMEOUT = 120

WORKER = r"""
import importlib.util, sys
import numpy as np
serve_path, x_path, out_path, bs = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
spec = importlib.util.spec_from_file_location("serve", serve_path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
X = np.load(x_path)
out = [np.asarray(mod.predict(X[i:i + bs])).astype(int).ravel() for i in range(0, len(X), bs)]
np.save(out_path, np.concatenate(out))
"""


def read_log():
    log = STATE / "actions.jsonl"
    if not log.exists():
        return []
    return [json.loads(line) for line in log.read_text().splitlines() if line.strip()]


def replay(entries):
    """Walk the log through the same gates the service enforces.

    Returns (gate_walk_ok, forced_recovery_ok, validated_sha). The walk is ok only if no
    gate was jumped, the clean validate belongs to the deploy that was promoted, and the
    log ends in submit.
    """
    s = {"reproduced": False, "deployed": False, "last": None, "diagnosed": False,
         "recovered": False, "promoted": False, "submitted": False, "validates": 0, "sha": None}
    for e in entries:
        op, r = e["op"], e["result"]
        if s["submitted"]:
            return False, s["recovered"], None
        if op == "reproduce":
            s["reproduced"] = True
        elif op == "deploy":
            if not s["reproduced"]:
                return False, s["recovered"], None
            s.update(deployed=True, last=None, diagnosed=False, promoted=False, sha=None)
        elif op == "validate":
            s["validates"] += 1
            if not s["deployed"] or s["validates"] > CFG["validate_budget"]:
                return False, s["recovered"], None
            s.update(last=r.get("status"), diagnosed=False, sha=r.get("release_sha256"))
        elif op == "diagnostics.read":
            if s["last"] != "FAILED":
                return False, s["recovered"], None
            s["diagnosed"] = True
        elif op == "recovery.apply":
            if not s["diagnosed"] or r.get("family") != "rebuild_artifact":
                return False, s["recovered"], None
            s.update(recovered=True, last=None, diagnosed=False, sha=None)
        elif op == "promote":
            if s["last"] != "clean":
                return False, s["recovered"], None
            s["promoted"] = True
        elif op == "submit":
            if not s["promoted"]:
                return False, s["recovered"], None
            s["submitted"] = True
        else:
            return False, s["recovered"], None
    return s["submitted"], s["recovered"], s["sha"]


def release_sha256(root):
    h = hashlib.sha256()
    for sub in RELEASE_DIRS:
        for p in sorted((Path(root) / sub).rglob("*")):
            if p.is_file():
                h.update(str(p.relative_to(root)).encode() + b"\0" + p.read_bytes() + b"\0")
    return h.hexdigest()


def run_release(deployed, X):
    """Stage the whole release (code, artifacts and data, as `validate` does) and run it in
    its own process. It receives X and nothing else."""
    with tempfile.TemporaryDirectory() as td:
        stage = Path(td) / "release"
        for sub in RELEASE_DIRS:
            if (deployed / sub).is_dir():
                shutil.copytree(deployed / sub, stage / sub, symlinks=True)
        xp, op = stage / ".x.npy", stage / ".out.npy"
        np.save(xp, X)
        kw = {"env": {"PATH": os.environ.get("PATH", ""), "PYTHONDONTWRITEBYTECODE": "1"}}
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            uid = int(CFG.get("sandbox_uid", 65534))
            os.chmod(td, 0o755)
            for p in [stage, *stage.rglob("*")]:
                os.chown(p, uid, uid, follow_symlinks=False)
            kw.update(user=uid, group=uid, extra_groups=[])
        p = subprocess.run(
            [sys.executable, "-c", WORKER, str(stage / "pipeline" / "serve.py"), str(xp), str(op),
             str(BATCH)], cwd=stage, capture_output=True, text=True, timeout=TIMEOUT, **kw)
        if p.returncode != 0 or not op.exists():
            tail = (p.stderr.strip().splitlines() or ["no output"])[-1]
            raise RuntimeError(f"release raised: {tail}")
        pred = np.load(op, allow_pickle=False)
    if pred.shape != (len(X),) or not np.isin(pred, (0, 1)).all():
        raise RuntimeError("release must return one 0/1 label per row")
    return pred


def terminal(validated_sha):
    """Score the deployed release on the hidden live stream. Returns (accuracy, agreement).

    agreement: share of rows that get the same answer when the same rows arrive in
    shuffled batches. The incident is a batch-dependent serving path, so this is the
    behaviour under test, whatever shape the fix takes.
    """
    deployed = STATE / "deployed"
    if release_sha256(deployed) != validated_sha:
        raise RuntimeError("deployed release is not the release that was validated")
    stream = np.load(SERVICE / "hidden_stream.npz")
    X, y = stream["X"], stream["y"]
    pred = run_release(deployed, X)
    perm = np.random.RandomState(CFG.get("invariance_seed", 20240229)).permutation(len(X))
    again = np.empty(len(X), dtype=int)
    again[perm] = run_release(deployed, X[perm])
    return float((pred == y).mean()), float((pred == again).mean())


def main():
    walk, recovery, validated_sha = replay(read_log())
    acc = agree = 0.0
    err = None
    if walk:
        try:
            acc, agree = terminal(validated_sha)
        except Exception as exc:  # noqa: BLE001
            err = f"{type(exc).__name__}: {exc}"
    else:
        err = "gate walk incomplete; release not scored"
    terminal_ok = acc >= BAR and agree >= CFG["invariance_min_agreement"]
    strict_pass = terminal_ok and walk and recovery
    reward = 1.0 if strict_pass else 0.0

    REWARD_DIR.mkdir(parents=True, exist_ok=True)
    (REWARD_DIR / "reward.txt").write_text(f"{reward}\n")
    print(json.dumps({"reward": reward, "terminal_accuracy": round(acc, 4),
                      "batch_agreement": round(agree, 4), "terminal_ok": terminal_ok,
                      "gate_walk_ok": walk, "forced_recovery_ok": recovery, "error": err}))


if __name__ == "__main__":
    main()
