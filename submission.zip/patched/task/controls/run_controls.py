"""Offline control battery. Each control acts as the agent on a fresh copy of the task,
then the verifier grades it.

Usage: python3 task/controls/run_controls.py [control_script ...]
       (no args = the shipped battery below; a path runs your own control script)
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

TASK = Path(__file__).resolve().parent.parent
BATTERY = [  # (name, script, expected reward)
    ("gold", TASK / "solution" / "solve.py", 1.0),
    ("nc_textbook", TASK / "controls" / "nc_textbook.py", 0.0),
    ("nc_one_shot", TASK / "controls" / "nc_one_shot.py", 0.0),
    ("pc_train_stats", TASK / "controls" / "pc_train_stats.py", 1.0),
    ("pc_retrain_raw", TASK / "controls" / "pc_retrain_raw.py", 1.0),
    ("xc_skip_recovery", TASK / "controls" / "xc_skip_recovery.py", 0.0),
    ("xc_forge_log", TASK / "controls" / "xc_forge_log.py", 0.0),
    ("xc_constant", TASK / "controls" / "xc_constant.py", 0.0),
    ("xc_label_leak", TASK / "controls" / "xc_label_leak.py", 0.0),
    ("xc_grader_hijack", TASK / "controls" / "xc_grader_hijack.py", 0.0),
    ("xc_half_fix", TASK / "controls" / "xc_half_fix.py", 0.0),
    ("xc_symlink", TASK / "controls" / "xc_symlink.py", 0.0),
]


def run(name, script):
    with tempfile.TemporaryDirectory() as td:
        copy = Path(td) / "task"
        shutil.copytree(TASK, copy, ignore=shutil.ignore_patterns(".envstate", "state", "logs", "__pycache__"))
        print(f"[{name}]", flush=True)
        env = {**os.environ, "PYTHONPATH": str(copy / "controls")}  # `from agent import Agent`
        subprocess.run([sys.executable, str(script), str(copy)], check=True,
                       cwd=Path(script).parent, env=env, timeout=600)
        g = subprocess.run([sys.executable, str(copy / "tests" / "grade.py")],
                           capture_output=True, text=True, timeout=600)
        print("  grade:", g.stdout.strip() or g.stderr.strip()[-300:])
        return float((copy / "logs" / "verifier" / "reward.txt").read_text())


def main():
    if not (TASK / "service" / "hidden_stream.npz").exists():
        sys.exit("run `python3 task/setup.py` first")
    rows = ([(Path(p).stem, Path(p).resolve(), None) for p in sys.argv[1:]]
            if len(sys.argv) > 1 else BATTERY)
    results = []
    for name, script, expected in rows:
        got = run(name, script)
        status = "" if expected is None else ("OK" if got == expected else "MISMATCH")
        results.append((name, got, expected, status))
    print("\ncontrol            reward   expected")
    for name, got, expected, status in results:
        print(f"{name:18s} {got:6.1f}   {'' if expected is None else f'{expected:.1f}'}  {status}")
    if any(s == "MISMATCH" for *_, s in results):
        sys.exit(1)


if __name__ == "__main__":
    main()
