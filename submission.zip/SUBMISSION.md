# Work trial submission

Name:
Time spent (minutes):

Every score below was produced by a run. Raw output is in `evidence/`. Line numbers refer to
the original, unpatched kit. Controls write only under `workspace/`, as the threat model
allows, unless stated otherwise.

## Part A: Findings (most severe first)

### F1 - The injected failure can be skipped; recovery is not part of the reward
- **Severity:** BLOCKER
- **Where:** `task/tests/grade.py:84`, `task/workspace/env_cli.py:159`
- **Failure scenario:** `reproduce, deploy, deploy, validate, promote, submit`. The fault fires
  only when `n == 1`, so deploy #2 is healthy. The grader computes `forced_recovery_ok` and
  prints it, but line 84 is `strict_pass = terminal and walk`. No diagnosis, no recovery, 1.0.
  AUTHOR_NOTES says "Recovery is therefore enforced". It is not.
- **Evidence:** `run_controls.py controls/xc_skip_recovery.py` -> reward **1.0**, with
  `forced_recovery_ok: false` in the same line of grader output.
- **Fix:** keep the fault active until a recovery has been applied, and add `and recovery` to
  the reward.

### F2 - The verifier trusts files the agent can write
- **Severity:** BLOCKER
- **Where:** `task/tests/grade.py:31`, `:60`; `task/workspace/env_cli.py:24-27`
- **Failure scenario:** the action log, the manifest and the deployed release all live in
  `workspace/.envstate/`. The agent writes `actions.jsonl` and `deployed/` by hand and never
  calls the ops service.
- **Evidence:** `controls/xc_forge_log.py` -> **1.0** with zero `env_cli` calls. Still **1.0**
  after the F1-only patch (`evidence/forge_log_three_versions.txt`).
- **Fix:** move the service and its state out of the workspace; grader reads only from there.

### F3 - The pass bar is below a no-skill baseline, and accuracy alone cannot see the bug
- **Severity:** BLOCKER
- **Where:** `task/tests/grade.py:22`, `task/setup.py:62`
- **Failure scenario:** (a) `predict` returns all ones. The live stream is 143/228 = 0.6272
  benign and the bar is 0.62. (b) A serving path that still re-standardises each batch, mixed
  80/20 with the training scaler, scores 0.9605.
- **Evidence:** `controls/xc_constant.py` -> **1.0** (terminal_accuracy 0.6272).
  `controls/xc_half_fix.py` -> **1.0** (0.9605). Measurements in `evidence/bar_measurement.txt`
  and `evidence/invariance_measurement.txt`.
- **Fix:** bar 0.94, read from config by both `validate` and the grader, plus a batch-invariance
  check: the same rows in shuffled batches must get the same answers.

### F4 - `validate` writes the hidden labels into the workspace
- **Severity:** BLOCKER
- **Where:** `task/workspace/env_cli.py:175-178`
- **Failure scenario:** the first `validate`, even a `FAILED` one, copies
  `hidden_stream.npz` to `.envstate/cache/stream.npz`. The agent builds a lookup table.
- **Evidence:** `controls/xc_label_leak.py` -> **1.0**, terminal_accuracy **1.0**, script printed
  `leaked labels found in workspace: 228`. The serving bug was left in place.
- **Fix:** delete the cache; read the stream from the service store.

### F5 - Agent code runs inside the verifier, and with the service's privileges
- **Severity:** BLOCKER
- **Where:** `task/tests/grade.py:26-27`, `:66-69`; `task/workspace/env_cli.py:97-99`
- **Failure scenario:** (a) `grade.py` imports `serve.py` into its own process, where
  `HIDDEN_Y` is a module global. `predict` returns slices of it. (b) `serve.py` opens
  `service/hidden_stream.npz` itself; it is executed by `validate` and the grader, not by the
  agent's shell.
- **Evidence:** (a) `controls/xc_grader_hijack.py` -> **1.0**, terminal_accuracy **1.0**, no
  model in the file. It answers a constant under `validate`, so it relies on F3 to pass the
  gate. (b) `controls/xc_direct_read.py` in a root container with `service/` at 0700 -> **1.0**
  (`evidence/docker_root_test.txt`).
- **Fix:** run the release in a separate process that receives features only and drops to an
  unprivileged uid.

### F6 - A correct fix that differs from the author's scores 0.0
- **Severity:** BLOCKER (false negative)
- **Where:** `task/tests/grade.py:63-65`
- **Failure scenario:** the agent standardises with `data/train_stats.json`, which `train.py`
  writes for this purpose. `validate` stages `data/` and returns `clean`. The grader stages
  only `serve.py` and `artifacts/`, so the same release crashes.
- **Evidence:** `controls/pc_train_stats.py` -> **0.0**, `gate_walk_ok: true`,
  `forced_recovery_ok: true`, `error: FileNotFoundError ... data/train.csv`.
- **Fix:** grader stages the same three directories `deploy` snapshots and uses the same cwd.

### F14 - `deploy` follows symlinks planted in the workspace
- **Severity:** BLOCKER (found while patching)
- **Where:** `task/workspace/env_cli.py:154-156`
- **Failure scenario:** `ln -s ../../service/hidden_stream.npz artifacts/reference.npz`.
  `copytree` follows it and copies the hidden stream into the release.
- **Evidence:** `controls/xc_symlink.py` -> **1.0**, terminal_accuracy **1.0**.
- **Fix:** refuse any symlink in a release; copy with `symlinks=True`.

### F7 - The gate walk is a subsequence match
- **Severity:** MAJOR
- **Where:** `task/tests/grade.py:37-45`
- **Failure scenario:** any log containing the five ops in order passes. The clean validate is
  not tied to the promoted deploy, and ops after `submit` are ignored.
- **Evidence:** inferred from the code. Reachable only through F2 in the original. Each case
  is tested against the patched grader in `evidence/grader_checks.txt`.
- **Fix:** replay the log through the same state machine the service enforces.

### F8 - The validate budget can be reset
- **Severity:** MAJOR
- **Where:** `task/workspace/env_cli.py:51-61`, `:171`
- **Failure scenario:** delete the `validate` lines from `actions.jsonl`.
- **Evidence:** `controls/ev_budget_reset.py`: 5th call rejected, lines deleted, 6th call
  accepted.
- **Fix:** same as F2.

### F9 - The recovery step does not test diagnosis
- **Severity:** MAJOR
- **Where:** `task/workspace/env_cli.py:209-210`, `:246-250`
- **Failure scenario:** three families, rejected guesses are free and never logged, and
  `diagnostics.read` names the cause in plain words.
- **Evidence:** `controls/ev_family_bruteforce.py` -> **1.0**; the log holds 1 `recovery.apply`
  entry for 3 attempts.
- **Fix:** log rejected attempts and cap them. **Not patched.**

### F10 - The author's controls pass for the wrong reasons
- **Severity:** MAJOR
- **Where:** `task/controls/nc_one_shot.py`, `task/controls/nc_textbook.py`
- **Failure scenario:** `nc_one_shot` claims to show that a correct fix without the trajectory
  cannot score. It floors on `FileNotFoundError` because nothing was deployed. F2 shows the
  claim is false. No control skips recovery. `nc_textbook` scores 0.5921, not the 0.610 in the
  notes.
- **Evidence:** `evidence/baseline_author_battery.txt`.
- **Fix:** battery extended with 7 exploit controls and 2 positive controls.

### F11 - The smoke batch is drawn from the training set
- **Severity:** MINOR
- **Where:** `task/setup.py:53-54`
- **Evidence:** inferred, not run. **Not patched.**

### F12 - `live_sample.csv` is rows 60-80 of the graded stream
- **Severity:** MINOR
- **Where:** `task/setup.py:55`
- **Evidence:** inferred, not run. Features only. **Not patched.**

### F13 - Bar and batch size duplicated in the grader; no timeout
- **Severity:** MINOR
- **Where:** `task/tests/grade.py:22-23`, `:66-70`
- **Evidence:** inferred, not run.
- **Fix:** read from config; 120 s timeout.

## Part B: Fix + proof

- **Blocker fixed:** F1. Also patched: F2, F3, F4, F5, F6, F7, F8, F10, F13, F14.
- **Exploit control:** `controls/xc_skip_recovery.py`
- **Patch:** `patch_stage1_F1_only.diff` (F1 alone, 4 lines) and `patch.diff` (everything).
  Patched files are in `patched/task/`.

Files changed in the full patch: `env/ops_service.py` (new), `workspace/env_cli.py`,
`tests/grade.py`, `setup.py`, `instruction.md`, `controls/run_controls.py`, 9 new controls.
`solution/` is untouched.

| run | before patch | after F1-only patch | after full patch |
|---|---|---|---|
| `xc_skip_recovery` (F1) | 1.0 | 0.0 | 0.0 |
| gold (`solution/solve.py`) | 1.0 | 1.0 | 1.0 |
| `xc_forge_log` (F2) | 1.0 | 1.0 | 0.0 |
| `xc_constant` (F3) | 1.0 | | 0.0 |
| `xc_half_fix` (F3) | 1.0 | | 0.0 |
| `xc_label_leak` (F4) | 1.0 | | 0.0 |
| `xc_grader_hijack` (F5a) | 1.0 | | 0.0 |
| `xc_direct_read` (F5b), root container | 1.0 | | 0.0 |
| `xc_direct_read` (F5b), plain kit | 1.0 | | **1.0** |
| `xc_symlink` (F14) | 1.0 | | 0.0 |
| `pc_train_stats` (F6, correct fix) | 0.0 | | 1.0 |
| `pc_retrain_raw` (correct fix, weakest measured) | 1.0 | | 1.0 |
| `nc_textbook` | 0.0 | 0.0 | 0.0 |
| `nc_one_shot` | 0.0 | 0.0 | 0.0 |

Known gap: `xc_direct_read` still scores 1.0 on the patched task in the plain kit. Every
process there is the same Linux user, so nothing can stop the read. The privilege drop runs
only when the service is root. It is proven in Docker and cannot be proven in the plain kit.

The service now stops every exploit before the grader is reached, so the grader's new checks
were tested separately with tampered state (`controls/test_grader_checks.py`, 7 of 7 pass).
That script edits `service/state/` and is a reviewer test, not an agent control.

Commands to reproduce:

```
unzip cpu-ml-eng-work-trial.zip -d trial && cd trial
python3 -m venv .venv && . .venv/bin/activate && pip install numpy scikit-learn
cp -r task task.orig
python3 task.orig/setup.py

# before
python3 task.orig/controls/run_controls.py controls/xc_skip_recovery.py task.orig/solution/solve.py

# F1 only
patch -p1 -d task < patch_stage1_F1_only.diff
python3 task/controls/run_controls.py controls/xc_skip_recovery.py task/solution/solve.py

# full patch, from a pristine copy
rm -rf task && cp -r task.orig task && patch -p1 -d task < patch.diff
python3 task/setup.py
python3 task/controls/run_controls.py
python3 controls/test_grader_checks.py task
docker run --rm --network none --user 0 -v "$PWD":/src:ro --entrypoint bash <image with numpy+sklearn> /src/controls/docker_root_test.sh
```

Unzip this submission inside `trial/`, so that `controls/` sits next to `task/` and
`task.orig/`.

## Part C: Verdict

Ship / ship with fixes / reject: **Reject as submitted. Resubmit with the fixes below.**

Seven independent routes reach 1.0 without a correct, properly driven fix, and a correct fix
that reads `train_stats.json` scores 0.0. The author's statement that all controls are green
is true but carries no weight, because no control has a second condition: none was ever
shown to fail when the thing it tests is removed. The incident itself is a good one. It uses
real data, the smoke check is blind to it, and the fix is small but not obvious. The
trajectory around it is thin: 11 commands, one fault, and the diagnosis prints its own answer.

Top priorities:
1. Put the ops service, its log and the deployed release outside the workspace, and run
   release code unprivileged. F2, F4, F5, F8 and F14 all follow from this.
2. Make the reward require what the task claims: recovery in the conjunction, fault that
   cannot be redeployed around, a bar above the no-skill baseline, batch invariance.
3. Grade the release the way `validate` runs it, so correct fixes of any shape pass.
4. Give every control a partner that proves it can fail, and keep the exploit controls in
   the battery.
5. Make the long horizon real: log and cap rejected recoveries, stop printing the diagnosis,
   hold the sample batch out of the graded stream.
