"""Reviewer-side test of the patched verifier. NOT an agent control: it edits
service/state/ on purpose, which the agent cannot do, to prove each grader check can fail
by itself even though the ops service would normally stop the run earlier.

Usage: python3 my_controls/test_grader_checks.py path/to/task
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

TASK = Path(sys.argv[1]).resolve()
RELEASE_DIRS = ("pipeline", "artifacts", "data")
HIJACK = '''import sys
import numpy as np


def predict(X):
    X = np.asarray(X, dtype=float)
    host = sys.modules.get("__main__")
    hx, hy = getattr(host, "HIDDEN_X", None), getattr(host, "HIDDEN_Y", None)
    if hx is not None and hy is not None:
        for i in range(len(hx) - len(X) + 1):
            if np.array_equal(hx[i:i + len(X)], X):
                return np.asarray(hy[i:i + len(X)]).astype(int)
    return np.ones(len(X), dtype=int)
'''


def release_sha256(root):
    h = hashlib.sha256()
    for sub in RELEASE_DIRS:
        for p in sorted((Path(root) / sub).rglob("*")):
            if p.is_file():
                h.update(str(p.relative_to(root)).encode() + b"\0" + p.read_bytes() + b"\0")
    return h.hexdigest()


def grade(copy):
    g = subprocess.run([sys.executable, str(copy / "tests" / "grade.py")],
                       capture_output=True, text=True, timeout=600)
    return json.loads(g.stdout)


def read(copy):
    log = copy / "service" / "state" / "actions.jsonl"
    return [json.loads(l) for l in log.read_text().splitlines() if l.strip()]


def write(copy, entries):
    log = copy / "service" / "state" / "actions.jsonl"
    log.write_text("".join(json.dumps({**e, "seq": i + 1}) + "\n" for i, e in enumerate(entries)))


def fresh_gold(td, name):
    copy = Path(td) / name / "task"
    shutil.copytree(TASK, copy, ignore=shutil.ignore_patterns(".envstate", "state", "logs", "__pycache__"))
    env = {**os.environ, "PYTHONPATH": str(copy / "controls")}
    subprocess.run([sys.executable, str(copy / "solution" / "solve.py"), str(copy)], check=True,
                   env=env, capture_output=True, timeout=600)
    return copy


failures = 0


def check(name, got, **want):
    global failures
    ok = all(got.get(k) == v for k, v in want.items())
    failures += not ok
    shown = {k: got.get(k) for k in ("reward", "terminal_accuracy", "batch_agreement",
                                     "gate_walk_ok", "forced_recovery_ok", "error")}
    print(f"{'PASS' if ok else 'FAIL'}  {name}\n      {json.dumps(shown)}")


with tempfile.TemporaryDirectory() as td:
    c = fresh_gold(td, "a")
    check("0. untouched gold run is accepted", grade(c), reward=1.0)

    c = fresh_gold(td, "b")
    e = read(c)
    first_failed = next(i for i, x in enumerate(e) if x["op"] == "validate")
    kept = [x for i, x in enumerate(e)
            if i != first_failed and x["op"] not in ("diagnostics.read", "recovery.apply")]
    write(c, kept)
    check("1. same release, log without the recovery -> recovery check decides", grade(c),
          reward=0.0, gate_walk_ok=True, forced_recovery_ok=False)

    c = fresh_gold(td, "c")
    sp = c / "service" / "state" / "deployed" / "pipeline" / "serve.py"
    sp.write_text(sp.read_text() + "\n# swapped after validate\n")
    check("2. release changed after the clean validate -> hash check decides", grade(c),
          reward=0.0, gate_walk_ok=True, forced_recovery_ok=True)

    c = fresh_gold(td, "d")
    write(c, read(c) + [{"op": "deploy", "result": {"deploy_id": 2, "status": "deployed"}}])
    check("3. an op after submit -> walk check decides", grade(c), reward=0.0, gate_walk_ok=False)

    c = fresh_gold(td, "e")
    e = read(c)
    write(c, [x for x in e if x["op"] != "promote"])
    check("4. submit without promote -> walk check decides", grade(c), reward=0.0, gate_walk_ok=False)

    c = fresh_gold(td, "f")
    e = read(c)
    clean = max(i for i, x in enumerate(e) if x["op"] == "validate")
    write(c, e[:clean] + [e[clean]] * 4 + e[clean + 1:])
    check("5. five validates against a budget of four -> walk check decides", grade(c),
          reward=0.0, gate_walk_ok=False)

    c = fresh_gold(td, "g")
    dep = c / "service" / "state" / "deployed"
    (dep / "pipeline" / "serve.py").write_text(HIJACK)
    e = read(c)
    for x in e:
        if x["op"] == "validate" and x["result"].get("status") == "clean":
            x["result"]["release_sha256"] = release_sha256(dep)
    write(c, e)
    check("6. label-stealing serve.py handed straight to the grader -> scores as a constant, not 1.0",
          grade(c), reward=0.0, terminal_accuracy=0.6272)

print("\nall grader checks behaved" if not failures else f"\n{failures} grader check(s) did not behave")
sys.exit(1 if failures else 0)
