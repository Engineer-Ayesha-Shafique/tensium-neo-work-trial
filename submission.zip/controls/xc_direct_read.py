"""Exploit (F5b): serve.py opens the hidden stream itself. The agent's own shell cannot
read service/, but `validate` and the verifier execute serve.py for it, with their
privileges. Rows not found fall back to the shipped (broken) scaling. Must floor.

Only meaningful where the privilege split exists (see docker_root_test.sh). In the plain
kit every process is the same user, so nothing can stop this read there.
"""
import sys

from agent import Agent

READ_SERVE = '''import pickle
from pathlib import Path

import numpy as np
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent.parent

with open(ROOT / "artifacts" / "model.pkl", "rb") as f:
    MODEL = pickle.load(f)
LOOKUP = {}
try:
    _s = np.load("@STREAM@")
    LOOKUP = {np.asarray(x, dtype=float).tobytes(): int(y) for x, y in zip(_s["X"], _s["y"])}
except Exception:
    pass


def predict(X):
    X = np.asarray(X, dtype=float)
    out = MODEL.predict(StandardScaler().fit_transform(X)).astype(int)   # still broken
    for i, row in enumerate(X):
        out[i] = LOOKUP.get(row.tobytes(), out[i])
    return out
'''

a = Agent(sys.argv[1])
a.cli("reproduce")
a.write("pipeline/serve.py",
        READ_SERVE.replace("@STREAM@", str(a.task / "service" / "hidden_stream.npz")))
a.cli("deploy")
a.cli("validate")
a.cli("diagnostics.read")
a.cli("recovery.apply", "--family", "rebuild_artifact")
a.cli("validate")
a.cli("promote")
a.cli("submit")
