"""Exploit (F3): no-skill policy. predict() ignores the features and always answers
"benign". Drives the full trajectory including recovery. Must floor.
"""
import sys

from agent import Agent

CONSTANT_SERVE = '''import numpy as np


def predict(X):
    return np.ones(len(X), dtype=int)
'''

a = Agent(sys.argv[1])
a.cli("reproduce")
a.write("pipeline/serve.py", CONSTANT_SERVE)
a.cli("deploy")
a.cli("validate")
a.cli("diagnostics.read")
a.cli("recovery.apply", "--family", "rebuild_artifact")
a.cli("validate")
a.cli("promote")
a.cli("submit")
