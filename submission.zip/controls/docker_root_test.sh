#!/usr/bin/env bash
# Runs inside a container as root. Lays the task out the way the image does
# (service/, tests/, env/ root-only 0700; workspace/ owned by uid 1000), then runs the ops
# service and the verifier as root, which is the only configuration in which the
# privilege-drop branch executes.
set -u
for which in task.orig task; do
  HERE=$(cd "$(dirname "$0")" && pwd)
  for ctl in solution/solve.py "$HERE/xc_direct_read.py"; do
    rm -rf /opt/t && mkdir -p /opt/t && cp -r /src/$which /opt/t/task
    rm -rf /opt/t/task/workspace/.envstate /opt/t/task/service/state /opt/t/task/logs
    chown -R 0:0 /opt/t && chown -R 1000:1000 /opt/t/task/workspace
    chmod 755 /opt/t /opt/t/task
    for d in service tests env; do [ -d /opt/t/task/$d ] && chmod -R go-rwx /opt/t/task/$d; done
    case $ctl in /*) script=$ctl ;; *) script=/opt/t/task/$ctl ;; esac
    echo "=== $which  $(basename $script)  (uid $(id -u))"
    PYTHONPATH=/opt/t/task/controls python3 "$script" /opt/t/task 2>&1 | grep -E "validate|promote|submit|deploy " | sed 's/^/  /' | cut -c1-150
    echo "  grade: $(python3 /opt/t/task/tests/grade.py 2>&1 | tail -1)"
  done
done
echo "=== can uid 65534 read the hidden stream directly?"
python3 - <<'PY'
import subprocess, sys
p = subprocess.run([sys.executable, "-c", "open('/opt/t/task/service/hidden_stream.npz','rb').read(1); print('READ OK')"],
                   user=65534, group=65534, extra_groups=[], capture_output=True, text=True)
print(" ", (p.stdout.strip() or p.stderr.strip().splitlines()[-1]))
PY
