"""Positive control: another correct fix that is not the author's. Removes scaling from the
serving path altogether by retraining the classifier on raw features. It is the weakest
legitimate fix measured (0.956 on the live stream), so it shows how much room the pass
bar leaves. Drives the full trajectory incl. recovery. Must score 1.0.
"""
import subprocess
import sys

from agent import Agent

RAW_SERVE = '''import pickle
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

with open(ROOT / "artifacts" / "model.pkl", "rb") as f:
    MODEL = pickle.load(f)


def predict(X):
    return MODEL.predict(np.asarray(X, dtype=float)).astype(int)   # no scaling at serve time
'''

a = Agent(sys.argv[1])
a.cli("reproduce")
train = (a.ws / "pipeline" / "train.py").read_text()
new = train.replace("LogisticRegression(max_iter=5000).fit(scaler.transform(X), y)",
                    "LogisticRegression(max_iter=20000).fit(X, y)")
assert new != train
a.write("pipeline/train.py", new)
subprocess.run([sys.executable, "-W", "ignore", str(a.ws / "pipeline" / "train.py")], check=True)
a.write("pipeline/serve.py", RAW_SERVE)
a.cli("reproduce")
a.cli("deploy")
a.cli("validate")
a.cli("diagnostics.read")
a.cli("recovery.apply", "--family", "rebuild_artifact")
a.cli("validate")
a.cli("promote")
a.cli("submit")
