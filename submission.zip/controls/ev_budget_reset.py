"""Evidence (F8): the validate budget is rebuilt from a log the agent can edit.
Not a reward exploit on its own; it shows the budget of 4 is not enforced."""
import sys

from agent import Agent

a = Agent(sys.argv[1])
a.cli("reproduce")
a.cli("deploy")
for _ in range(4):
    a.cli("validate")
print("  -- 5th call, budget spent:")
a.cli("validate")
log = a.ws / ".envstate" / "actions.jsonl"
if log.exists():
    kept = [l for l in log.read_text().splitlines() if '"op": "validate"' not in l]
    log.write_text("\n".join(kept) + "\n")
    print("  -- validate lines deleted from workspace/.envstate/actions.jsonl")
else:
    print("  -- no log in workspace/.envstate to edit")
a.cli("validate")
