"""Exploit (F1): the correct fix, but the injected failure is never recovered.

The fault fires on deploy #1 only, so a second `deploy` produces a healthy release and the
agent never has to diagnose or recover anything. Touches workspace/ only. Must floor.
"""
import sys

from agent import Agent

FIXED_SERVE = '''import pickle
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

with open(ROOT / "artifacts" / "model.pkl", "rb") as f:
    MODEL = pickle.load(f)
with open(ROOT / "artifacts" / "scaler.pkl", "rb") as f:
    SCALER = pickle.load(f)


def predict(X):
    X = np.asarray(X, dtype=float)
    return MODEL.predict(SCALER.transform(X)).astype(int)
'''

a = Agent(sys.argv[1])
a.cli("reproduce")
a.write("pipeline/serve.py", FIXED_SERVE)
a.cli("deploy")        # deploy #1: artifact truncated
a.cli("deploy")        # deploy #2: no fault injected
a.cli("validate")
a.cli("promote")
a.cli("submit")
