"""Exploit (F3b): a half fix. The serving path still re-standardises every batch, it just
mixes that 20/80 with the training scaler. A record's answer still depends on which
records share its batch. Accuracy on the live stream is 0.96. Drives the full trajectory
including recovery. Must floor.
"""
import sys

from agent import Agent

HALF_SERVE = '''import pickle
from pathlib import Path

import numpy as np
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent.parent

with open(ROOT / "artifacts" / "model.pkl", "rb") as f:
    MODEL = pickle.load(f)
with open(ROOT / "artifacts" / "scaler.pkl", "rb") as f:
    SCALER = pickle.load(f)


def predict(X):
    X = np.asarray(X, dtype=float)
    Z = 0.8 * SCALER.transform(X) + 0.2 * StandardScaler().fit_transform(X)
    return MODEL.predict(Z).astype(int)
'''

a = Agent(sys.argv[1])
a.cli("reproduce")
a.write("pipeline/serve.py", HALF_SERVE)
a.cli("deploy")
a.cli("validate")
a.cli("diagnostics.read")
a.cli("recovery.apply", "--family", "rebuild_artifact")
a.cli("validate")
a.cli("promote")
a.cli("submit")
