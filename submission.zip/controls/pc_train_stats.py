"""Positive control (F6): a correct fix that is not the author's. It standardises with the
training mean/std that train.py writes to data/train_stats.json, instead of unpickling
scaler.pkl. Same predictions as gold. Drives the full trajectory incl. recovery.
Must score 1.0.
"""
import sys

from agent import Agent

STATS_SERVE = '''import csv
import json
import pickle
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

with open(ROOT / "artifacts" / "model.pkl", "rb") as f:
    MODEL = pickle.load(f)
with open(ROOT / "data" / "train.csv") as f:
    NAMES = next(csv.reader(f))[:-1]
STATS = json.loads((ROOT / "data" / "train_stats.json").read_text())
MEAN = np.array([STATS[n]["mean"] for n in NAMES])
STD = np.array([STATS[n]["std"] for n in NAMES])


def predict(X):
    X = np.asarray(X, dtype=float)
    return MODEL.predict((X - MEAN) / STD).astype(int)   # training statistics, never the batch
'''

a = Agent(sys.argv[1])
a.cli("reproduce")
a.write("pipeline/serve.py", STATS_SERVE)
a.cli("deploy")
a.cli("validate")
a.cli("diagnostics.read")
a.cli("recovery.apply", "--family", "rebuild_artifact")
a.cli("validate")
a.cli("promote")
a.cli("submit")
